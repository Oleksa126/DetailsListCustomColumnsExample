declare interface IDetailsListCustomColumnsExampleWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ClientModeLabel: string;

}

declare module 'DetailsListCustomColumnsExampleWebPartStrings' {
  const strings: IDetailsListCustomColumnsExampleWebPartStrings;
  export = strings;
}
