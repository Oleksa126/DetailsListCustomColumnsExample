/* tslint:disable */
require("./DetailsListCustomColumnsExample.module.css");
const styles = {
  detailsListCustomColumnsExample: 'detailsListCustomColumnsExample_433e4b2c',
  container: 'container_433e4b2c',
  row: 'row_433e4b2c',
  column: 'column_433e4b2c',
  'ms-Grid': 'ms-Grid_433e4b2c',
  title: 'title_433e4b2c',
  subTitle: 'subTitle_433e4b2c',
  description: 'description_433e4b2c',
  button: 'button_433e4b2c',
  label: 'label_433e4b2c',
};

export default styles;
/* tslint:enable */