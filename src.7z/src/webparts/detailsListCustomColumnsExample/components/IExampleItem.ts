export interface IExampleItem {
    // userId:string,
    thumbnail: string;
    Name: string;
    WorkPhone: string;
    Email: string;
    Department: string;
  }
  